using Akka.Actor;
using Akka.Configuration;
using Microsoft.Extensions.Configuration;
using OrderService.Actor;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Load Akka.NET config from appsettings.json
var akkaConfig = builder.Configuration.GetSection("Akka");

var config = ConfigurationFactory.ParseString($@"
    akka {{
        actor.provider = ""Akka.Remote.RemoteActorRefProvider, Akka.Remote""
        remote.dot-netty.tcp {{
            hostname = ""{akkaConfig["Remote:Hostname"]}""
            port = {akkaConfig["Remote:Port"]}
        }}
    }}
");

// Create Actor System
var system = ActorSystem.Create(akkaConfig["SystemName"], config);

// Define remote PaymentService actor selection
var paymentActorPath = $"akka.tcp://PaymentSystem@{akkaConfig["PaymentService:Hostname"]}:{akkaConfig["PaymentService:Port"]}/user/paymentActor";
var paymentSyncActorPath = $"akka.tcp://PaymentSystem@{akkaConfig["PaymentService:Hostname"]}:{akkaConfig["PaymentService:Port"]}/user/paymentSyncActor";
var paymentActorSelection = system.ActorSelection(paymentActorPath);
var paymentSyncActorSelection = system.ActorSelection(paymentSyncActorPath);


// Create OrderActor and inject ActorSelection
var orderActor = system.ActorOf(Props.Create(() => new OrderActor(paymentActorSelection)), "orderActor");
var orderSyncActor = system.ActorOf(Props.Create(() => new OrderSyncActor(paymentSyncActorSelection)), "orderSyncActor");


builder.Services.AddSingleton(orderActor);
builder.Services.AddSingleton(orderSyncActor);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseRouting();
app.MapControllers();
app.Run();
