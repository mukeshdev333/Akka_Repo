﻿using Akka.Actor;
using static Common.Messages;

namespace OrderService.Actor;

public class OrderActor : ReceiveActor
{
    private readonly ActorSelection _paymentActorselection;

    public OrderActor(ActorSelection paymentActorselection)
    {
        _paymentActorselection = paymentActorselection;
        
        Receive<OrderCreated>(order =>
        {
            Console.WriteLine($"[Orderservice] Order Received : {order.OrderId}");

            _paymentActorselection.Tell(new ProcessPayment(order.OrderId,order.Amount));
        });
    }
}
