﻿using Akka.Actor;
using static Common.Messages;

namespace OrderService.Actor;

public class OrderSyncActor : ReceiveActor
{
    private readonly ActorSelection _actorSelection;

    public OrderSyncActor(ActorSelection actorSelection)
    {
        _actorSelection = actorSelection;

        ReceiveAsync<OrderCreated>(async order =>
        {
            Console.WriteLine("Order Prcessig sync");

            var paymentResponse = await _actorSelection.Ask<PaymentProcessed>(new ProcessPayment(order.OrderId, order.Amount), TimeSpan.FromSeconds(10));

            Sender.Tell(new OrderResponse(order.OrderId, paymentResponse.Success));
        });
    }
}
