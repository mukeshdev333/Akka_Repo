﻿using Akka.Actor;
using Microsoft.AspNetCore.Mvc;
using static Common.Messages;

namespace OrderService.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrderController : ControllerBase
{
    private readonly IActorRef _orderAsyncActor;
    private readonly IActorRef _orderSyncActor;

    public OrderController(IActorRef orderAsyncActor, IActorRef orderSyncActor)
    {
        _orderAsyncActor = orderAsyncActor;
        _orderSyncActor = orderSyncActor;
    }

    [HttpPost]
    [Route("/Create-Aync")]
    public IActionResult CreateOrder([FromBody] OrderCreated order)
    {
        _orderAsyncActor.Tell(order);
        return Ok("order sent for processing");
    }

    [HttpPost]
    [Route("/Create-Sync")]
    public async Task<IActionResult> CreateOrderSync([FromBody] OrderCreated order)
    {
        var response= await _orderSyncActor.Ask<OrderResponse>(order, TimeSpan.FromSeconds(10));
        if (response.Success)
            return Ok($"Order {order.OrderId} processed successfully");
        else
            return BadRequest($"Order {order.OrderId} processing failed.");
    }
}
