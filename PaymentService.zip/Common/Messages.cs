﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Messages
    {
        public record OrderCreated(Guid OrderId, decimal Amount);
        public record ProcessPayment(Guid OrderId, decimal Amount);

        public record PaymentProcessed(Guid OrderId, bool Success);

        public record OrderResponse (Guid OrderId, bool Success);
        public record GenerateInvoice(Guid OrderId,bool Success);
    }
}
