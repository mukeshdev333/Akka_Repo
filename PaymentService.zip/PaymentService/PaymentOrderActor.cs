﻿using Akka.Actor;

namespace PaymentService;

public class PaymentOrderActor : ReceiveActor
{
}
