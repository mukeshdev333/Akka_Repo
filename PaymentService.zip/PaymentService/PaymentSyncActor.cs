﻿using Akka.Actor;
using static Common.Messages;

namespace PaymentService;

public class PaymentSyncActor : ReceiveActor
{
    public PaymentSyncActor()
    {
        Receive<ProcessPayment>(payment =>
        {
            Console.WriteLine($"Sync");

            Sender.Tell(new PaymentProcessed(payment.OrderId,true));
        });
    }
}
