﻿using Akka.Actor;
using Microsoft.AspNetCore.Mvc;
using static Common.Messages;

namespace PaymentService.Controllers;

[ApiController]
[Route("/api/[controller]")]
public class PaymentController : ControllerBase
{
    private readonly IActorRef _orderActor;
    public PaymentController(IActorRef orderActor)
    {
        _orderActor = orderActor;
    }

    [HttpPost]
    public IActionResult GenerateInvoice([FromBody] GenerateInvoice generateInvoice)
    {
        _orderActor.Tell(generateInvoice);
        return Ok();
    }
}
