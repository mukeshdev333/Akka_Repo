﻿using Akka.Actor;
using static Common.Messages;

namespace PaymentService;

public class PaymentActor : ReceiveActor
{
    public PaymentActor()
    {
        Receive<ProcessPayment>(payment =>
        {
            Console.WriteLine($"[PaymentService] Processing Payment for order : {payment.OrderId}");

            Sender.Tell(new PaymentProcessed(payment.OrderId,true));
        });
    }
}
