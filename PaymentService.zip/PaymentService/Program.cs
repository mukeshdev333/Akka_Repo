using Akka.Actor;
using Akka.Configuration;
using Microsoft.Extensions.Configuration;
using PaymentService;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Load Akka.NET config from appsettings.json
var akkaConfig = builder.Configuration.GetSection("Akka");
var config = ConfigurationFactory.ParseString($@"
    akka {{
        actor.provider = ""Akka.Remote.RemoteActorRefProvider, Akka.Remote""
        remote.dot-netty.tcp {{
            hostname = ""{akkaConfig["Remote:Hostname"]}""
            port = {akkaConfig["Remote:Port"]}
        }}
    }}
");

// Create Actor System
var system = ActorSystem.Create(akkaConfig["SystemName"], config);

// Create Payment Actor
var paymentActor = system.ActorOf(Props.Create(() => new PaymentActor()), "paymentActor");
var paymentSyncActor = system.ActorOf(Props.Create(() => new PaymentSyncActor()), "paymentSyncActor");


builder.Services.AddSingleton(paymentActor);
builder.Services.AddSingleton(paymentSyncActor);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseRouting();
app.MapControllers();
app.Run();
